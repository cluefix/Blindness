--[[math.randomseed(os.time())

function random(count)
    local letters = {}
    for i = 1, count do
        local leters = string.char(math.random(97, 122))
        local isCapital = math.random(0, 1)
        if isCapital == 1 then
            leters = string.upper(leters)
        end
        table.insert(letters, leters)
    end
    return table.concat(letters)
end

local leters = random(20)

getMainForm().Caption = leters
getApplication().Title = leters
]]
-- discontinued until i find a way
getMainForm().Caption = "blindness"
getApplication().Title = "blindness"